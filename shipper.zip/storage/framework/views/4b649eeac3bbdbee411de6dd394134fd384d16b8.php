<script src="https://cdn.polyfill.io/v2/polyfill.min.js"></script>
<script src="<?php echo e(mix('/js/admin.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/js/icon-select.js')); ?>"></script>
<?php /**PATH C:\wamp64\www\shipp\resources\views/seo/partials/main-bottom-scripts.blade.php ENDPATH**/ ?>