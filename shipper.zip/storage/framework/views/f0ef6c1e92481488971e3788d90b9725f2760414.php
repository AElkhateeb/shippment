<?php $__env->startSection('content'); ?>

   <?php //$data=['id'=>0];
     /*  echo "<pre>";

    print_r($data['sliders']);
    print_r($data);
   echo "</pre>";
    die();

     @include('front\productView',$data)
     */
   $sliders = $data['sliders'];
   $categories = $data['categories'];
   $about = $data['about'];
    ?>
   <?php echo $__env->make('front\slider',compact('sliders'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('front\features',compact('categories'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('front\posts',$data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('front\quality',compact('about'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('front\portfolio',compact('about'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php
// @include('front\rate',$data)
?>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/front\index.blade.php ENDPATH**/ ?>