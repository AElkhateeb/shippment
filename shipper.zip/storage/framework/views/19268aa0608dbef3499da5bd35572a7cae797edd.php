<header class="app-header navbar">
    <button class="navbar-toggler sidebar-toggler d-lg-none" type="button" data-toggle="sidebar-show">
        <span class="navbar-toggler-icon"></span>
    </button>
	<?php if(View::exists('seo.layout.logo')): ?>
        <?php echo $__env->make('seo.layout.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
    <ul class="nav navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a role="button" class="dropdown-toggle nav-link">
                <span>
                    <?php if(Auth::check() && Auth::user()->avatar_thumb_url): ?>
                        <img src="<?php echo e(Auth::user()->avatar_thumb_url); ?>" class="avatar-photo">
                    <?php elseif(Auth::check() && Auth::user()->first_name && Auth::user()->last_name): ?>
                        <span class="avatar-initials"><?php echo e(mb_substr(Auth::user()->first_name, 0, 1)); ?><?php echo e(mb_substr(Auth::user()->last_name, 0, 1)); ?></span>
                    <?php elseif(Auth::check() && Auth::user()->name): ?>
                        <span class="avatar-initials"><?php echo e(mb_substr(Auth::user()->name, 0, 1)); ?></span>
                    <?php elseif(Auth::guard(config('seo-auth.defaults.guard'))->check() && Auth::guard(config('seo-auth.defaults.guard'))->user()->first_name && Auth::guard(config('seo-auth.defaults.guard'))->user()->last_name): ?>
                        <span class="avatar-initials"><?php echo e(mb_substr(Auth::guard(config('seo-auth.defaults.guard'))->user()->first_name, 0, 1)); ?><?php echo e(mb_substr(Auth::guard(config('seo-auth.defaults.guard'))->user()->last_name, 0, 1)); ?></span>
                    <?php else: ?>
                        <span class="avatar-initials"><i class="fa fa-user"></i></span>
                    <?php endif; ?>

                    <?php if(!is_null(config('seo-auth.defaults.guard'))): ?>
                        <span class="hidden-md-down"><?php echo e(Auth::guard(config('seo-auth.defaults.guard'))->check() ? Auth::guard(config('seo-auth.defaults.guard'))->user()->full_name : 'Anonymous'); ?></span>
                    <?php else: ?>
                        <span class="hidden-md-down"><?php echo e(Auth::check() ? Auth::user()->full_name : 'Anonymous'); ?></span>
                    <?php endif; ?>

                </span>
                <span class="caret"></span>
            </a>
            <?php if(View::exists('seo.layout.profile-dropdown')): ?>
                <?php echo $__env->make('seo.layout.profile-dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    </ul>
</header>
<?php /**PATH C:\wamp64\www\shipp\resources\views/seo/partials/header.blade.php ENDPATH**/ ?>