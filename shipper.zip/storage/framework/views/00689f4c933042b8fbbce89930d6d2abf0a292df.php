<section id="section-features" class="pb-0">
    <div class="container">
        <div class="row">
            <div class="text-center">
                <h2 class="wow fadeIn" data-wow-delay="0">Why Choose Us?
                    <span>Find reasons to choose us as your freight partner</span>
                </h2>
                <div class="small-border wow flipInY" data-wow-delay=".2s" data-wow-duration=".8s"></div>
            </div>
            <div class="divider-single"></div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-6">
                    <div class="box-with-icon-left">
                        <i class="fa <?php echo e($about['link1']); ?> icon-big"></i>
                        <div class="text">
                            <h2><?php echo e($about['title']); ?></h2>
                            <p><?php echo $about['text']; ?> </p>
                            <div class="divider-single"></div>
                        </div>
                    </div>
                </div>
            <!-- end .item -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>

        </div>
    </div>
</section>
<?php /**PATH C:\wamp64\www\shipp\resources\views/front\why-us.blade.php ENDPATH**/ ?>