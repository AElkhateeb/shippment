<?php
$about = $data['about'];
$pro = $data['pro'];
$page = $data['page'];
$header=[
    'img'=>$page['media_url'],
    'title'=>$page['title'],
    'h2'=>
        $page['h1'],
];
$header2=[
    'shade'=>'Recovery',
    'h2'=>'About - Us',
    'text'=>
        '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor <br class="visible-lg"> incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>',
];




?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', $page['title']); ?>
<?php $__env->startSection('description',  $page['description']); ?>
<?php echo $__env->make('front.page-header',compact('header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- /.page-header -->

    <!-- section-full include('front\page-header2',compact('header2')) -->

   <!-- section-full -->

    <!-- identity -->
    <?php echo $__env->make('front.identity',compact('about'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- why us ? -->
<section class="no-padding">
    <div class="container-fullwidth">
        <div id="bg-box-service-1" class="one-tow">
            <div class="bg-color-fx light-text padding-5 text-center">

            </div>
        </div>
        <div id="bg-box-service-2" class="one-tow">
            <div class="bg-color-fx light-text padding-5 text-center">

            </div>
        </div>

    </div>
</section>
    <?php echo $__env->make('front.why-us',compact('pro'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- team -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/front/about.blade.php ENDPATH**/ ?>