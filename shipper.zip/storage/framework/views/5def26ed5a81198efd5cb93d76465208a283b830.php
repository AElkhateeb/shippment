<?php
$service = $data['service'];
$page = $data['page'];
$header=[
    'img'=>$page['media_url'],
    'title'=>$page['title'],
    'h2'=>
        $service[0]['title'],
];
$header2=[
    'shade'=>'Recovery',
    'h2'=>'About - Us',
    'text'=>
        '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor <br class="visible-lg"> incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>',
];


// $about = $data['about'];

?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', $service[0]['title']); ?>
<?php $__env->startSection('description',  $page['description']); ?>
    <?php echo $__env->make('front.page-header',compact('header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="content" class="no-top no-bottom">
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">

                        <div class="blog-details single-post-item format-standard">
                            <div class="post-details">

                                <div class="post-featured-img">
                                    <img class="img-fluid" src="<?php echo e(URL::asset($service[0]['media_url'])); ?>" alt="">
                                </div>

                                <div class="post-top-meta">
                                </div>
                                <h2 class="post-title"><?php echo e($service[0]['title']); ?></h2>
                                  <blockquote>
                                    <span class="icon"><i class="fas fa-quote-left"></i></span>
                                    <p class="texter"><?php echo strip_tags($service[0]['text']); ?></p>

                                </blockquote>
                                <?php echo $service[0]['body']; ?>




                            </div>
                        </div>


                    </div>

                    <div class="divider-single"></div>
                    <div class="divider-half"></div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/front/service.blade.php ENDPATH**/ ?>