<section class="no-padding">
    <div class="container-fullwidth">
        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="bg-box-service-<?php echo e($serviceId); ?>" class="one-fourth">
                <div class="bg-color-fx light-text padding-5 text-center">
                    <h3><?php echo e($service['title']); ?></h3>
                    <div class="tiny-border margintop10 marginbottom10"></div>
                    <img src="<?php echo e(URL::asset($service['media_url'])); ?>" class="img-responsive margintop20 marginbottom20 wow fadeInRight" alt="" />
                    <p><?php echo $service['text']; ?></p>
                    <a href="<?php echo e(url(App::currentLocale().'/service/'.$service['id'])); ?>" class="btn-arrow hover-light"><span class="line"></span><span class="url">View Details</span></a>
                </div>
            </div>
            <?php $serviceId+1; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div> <!-- /.container -->

</section>
<?php /**PATH C:\wamp64\www\shipp\resources\views/front/doing.blade.php ENDPATH**/ ?>