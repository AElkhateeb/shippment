<?php

$page = $data['page'];
$header=[
    'img'=>$page['media_url'],
    'title'=>$page['title'],
    'h2'=>
        $page['h1'],
];
$header2=[
    'shade'=>'Recovery',
    'h2'=>'About - Us',
    'text'=>
        '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor <br class="visible-lg"> incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>',
];

$serviceId=1;
// $about = $data['about'];
$service = $data['service'];

?>

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', $page['title']); ?>
<?php $__env->startSection('description',  $page['description']); ?>
    <?php echo $__env->make('front.page-header',compact('header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ================================= Blog Grid ================================== -->
    <section>
        <div class="container">

            <div class="row">
                <div class="col text-center">
                    <div class="sec-heading center">
                        <h2>Trending Articles</h2>
                        <p>We post regulary most powerful articles for help and support.</p>
                    </div>
                </div>
            </div>

        </div>
    </section>
            <section class="no-padding">
            <div class="container-fullwidth">
            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Single blog Grid -->
                    <div id="bg-box-service-<?php echo e($serviceId); ?>" class="one-tow">
                        <div class="bg-color-fx light-text padding-5 text-center">
                            <h3><?php echo e($service['title']); ?></h3>
                            <div class="tiny-border margintop10 marginbottom10"></div>
                            <img src="<?php echo e(URL::asset($service['media_url'])); ?>" class="img-responsive margintop20 marginbottom20 wow fadeInRight" alt="" />
                            <p><?php echo $service['text']; ?></p>
                            <a href="<?php echo e(url(App::currentLocale().'/service/'.$service['id'])); ?>" class="btn-arrow hover-light"><span class="line"></span><span class="url">View Details</span></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            </section>
    <section></section>

    <!-- ================= Blog Grid End ================= -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/front/services.blade.php ENDPATH**/ ?>