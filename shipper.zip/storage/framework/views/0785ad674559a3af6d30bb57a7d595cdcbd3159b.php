<div id="content">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <img src="<?php echo e(URL::asset($about['media_url'])); ?>" class="img-responsive" alt="">
                    <div class="divider-single"></div>
                    <h2><?php echo e($about['title']); ?></h2>
                    <div class="tiny-border"></div>
                    <p><?php echo $about['text']; ?></p>

                </div>
            <!-- end .item -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div> <!-- end .about-me-carousel -->
    </div> <!-- /.container -->
</div>
<?php /**PATH C:\wamp64\www\shipp\resources\views/front\identity2.blade.php ENDPATH**/ ?>