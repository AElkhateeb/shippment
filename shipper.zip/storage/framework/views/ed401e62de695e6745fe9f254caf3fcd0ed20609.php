<?php $__env->startSection('content'); ?>
    <?php
    $header=[
        'img'=>'img/page/about-me.jpg',
        'h2'=>'About - Us',
        'links'=>
            '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>',
    ];
    $header2=[
        'shade'=>'Recovery',
        'h2'=>'About - Us',
        'text'=>
            '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor <br class="visible-lg"> incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>',
    ];

    $serviceId=1;
    // $about = $data['about'];
    $service = $data['service'];
    ?>
    <?php echo $__env->make('front\page-header',compact('header'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="no-padding">
        <div class="container-fullwidth">
            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="bg-box-service-<?php echo e($serviceId); ?>" class="one-third">
                    <div class="bg-color-fx light-text padding-5 text-center">
                        <h3><?php echo e($service['name']); ?></h3>

                        <ul class="list-1-col">
                            <li><a href="#"><?php echo e($service['weight']); ?></a></li>
                            <li><a href="#"><?php echo e($service['number']); ?></a></li>
                            <li><a href="#"><?php echo e(__('front.pricing city')); ?></a></li>
                        </ul>
                        <div class="divider-single"></div>
                        <a href="<?php echo e(url(App::currentLocale().'/service/'.$service['id'])); ?>" class="btn-border popup-gmaps hover-light"><span class="line"></span><span class="url">View Details</span></a>
                    </div>
                </div>
                <?php $serviceId+1; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div> <!-- /.container -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/front\pricing.blade.php ENDPATH**/ ?>