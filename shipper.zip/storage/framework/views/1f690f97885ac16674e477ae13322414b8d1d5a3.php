
<section class="no-padding mt-90 absolute width100 z-index10 height90px overlaydark70">
    <div class="container">
        <div class="row-fluid <?= (App::currentLocale()=='en')? '': 'arabic'?>">

                <?php $__currentLoopData = $branches['contact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="info-box padding20">
                            <i class="fa <?php echo e($contact['icon']); ?>"></i>
                            <div class="info-box_text">
                                <div class="info-box_title"><?php echo e($contact['title']); ?></div>
                                <div class="info-box_subtite"><?php echo $contact['text']; ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

            <div class="col-md-4"></div>
        </div>
    </div>
</section>

<!-- / #overlay  -->
<?php /**PATH C:\wamp64\www\shipp\resources\views/front/overlay.blade.php ENDPATH**/ ?>