<?php echo "<?php";
?>


namespace <?php echo e($exportNamespace); ?>;

use <?php echo e($modelFullName); ?>;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class <?php echo e($classBaseName); ?> implements FromCollection, WithMapping, WithHeadings
{
    /**
     * <?php echo e('@'); ?>return Collection
     */
    public function collection()
    {
        return <?php echo e($modelBaseName); ?>::all();
    }

    /**
     * <?php echo e('@'); ?>return array
     */
    public function headings(): array
    {
        return [
<?php $__currentLoopData = $columnsToExport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            trans('admin.<?php echo e($modelLangFormat); ?>.columns.<?php echo e($column); ?>'),
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];
    }

    /**
     * <?php echo e('@'); ?>param <?php echo e($modelBaseName); ?> $<?php echo e($modelVariableName); ?>

     * <?php echo e('@'); ?>return array
     *
     */
    public function map($<?php echo e($modelVariableName); ?>): array
    {
        return [
<?php $__currentLoopData = $columnsToExport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $<?php echo e($modelVariableName); ?>-><?php echo e($column); ?>,
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];
    }
}
<?php /**PATH C:\wamp64\www\shipp\vendor\brackets\admin-generator\src/../resources/views/export.blade.php ENDPATH**/ ?>