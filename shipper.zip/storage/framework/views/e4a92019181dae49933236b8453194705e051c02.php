<link href="<?php echo e(mix('/css/admin.css')); ?>" rel="stylesheet">
<?php /**PATH C:\wamp64\www\shipp\resources\views/admin/partials/main-styles.blade.php ENDPATH**/ ?>