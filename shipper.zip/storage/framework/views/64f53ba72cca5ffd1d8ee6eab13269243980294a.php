<?php $__env->startSection('body'); ?>

    <div class="welcome-quote">

	    <blockquote>
		    <?php echo e(explode(" - ", $inspiration)[0]); ?>

		    <cite>
			    <?php echo e(explode(" - ", $inspiration)[1]); ?>

		    </cite>
	    </blockquote>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('seo.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/seo/homepage/index.blade.php ENDPATH**/ ?>