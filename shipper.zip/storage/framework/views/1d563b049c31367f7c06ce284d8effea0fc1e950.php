<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav expandable">
            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.content')); ?></li>
            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#">
                    <i class="nav-icon icon-puzzle"></i> Web Site
                </a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/sliders')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.slider.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/identities')); ?>"><i class="nav-icon icon-plane"></i> <?php echo e(trans('admin.identity.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/pros')); ?>"><i class="nav-icon icon-ghost"></i> <?php echo e(trans('admin.pro.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/services')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.service.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/jobs')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.job.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/applications')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.application.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/testimonials')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.testimonial.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/socials')); ?>"><i class="nav-icon icon-flag"></i> <?php echo e(trans('admin.social.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/contacts')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.contact.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/clients')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.client.title')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/pages')); ?>"><i class="nav-icon icon-globe"></i> <?php echo e(trans('admin.page.title')); ?></a></li>
                </ul>
            </li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/shipments')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.shipment.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/places')); ?>"><i class="nav-icon icon-magnet"></i> <?php echo e(trans('admin.place.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/roads')); ?>"><i class="nav-icon icon-graduation"></i> <?php echo e(trans('admin.road.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/payment-methods')); ?>"><i class="nav-icon icon-ghost"></i> <?php echo e(trans('admin.payment-method.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/wallets')); ?>"><i class="nav-icon icon-plane"></i> <?php echo e(trans('admin.wallet.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/withdrawals')); ?>"><i class="nav-icon icon-energy"></i> <?php echo e(trans('admin.withdrawal.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/contacts')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.contact.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/branches')); ?>"><i class="nav-icon icon-globe"></i> <?php echo e(trans('admin.branch.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/receiveres')); ?>"><i class="nav-icon icon-compass"></i> <?php echo e(trans('admin.receivere.title')); ?></a></li>
           

            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.settings')); ?></li>
            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#">
                    <i class="nav-icon icon-puzzle"></i> Users access
                </a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/admin-users')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage admin ')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/ceo-admin')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage ceo ')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/manger-admin')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage manger ')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/employee-admin')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage employee ')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/seo-admin')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage seo ')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/shipper-admin')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage shipper ')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/account-admin')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage account ')); ?></a></li>
                </ul>
            </li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/translations')); ?>"><i class="nav-icon icon-location-pin"></i> <?php echo e(__('Translations')); ?></a></li>
            
            
        </ul>

    </nav>

    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH C:\wamp64\www\shipp\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>