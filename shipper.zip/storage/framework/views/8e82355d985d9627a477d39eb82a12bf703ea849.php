<footer class="app-footer">
    <div class="container-fluid">
        <div class="container-xl">
            <span class="pull-right"><?php echo e(trans('brackets/admin-ui::admin.footer.powered_by')); ?> <a href="https://www.getcraftable.com">Craftable</a></span>
        </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\shipp\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>