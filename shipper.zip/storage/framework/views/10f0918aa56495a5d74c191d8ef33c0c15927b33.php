<?php
$serviceId=1;
$data = $data;
$sliders = $data['sliders'];
$branches = $data['branches'];
$about = $data['about'];
$service = $data['service'];
$pro = $data['pro'];
$testimonial = $data['testimonial'];
//die(json_encode($data['sliders']));
?>

<?php $__env->startSection('content'); ?>

    <!-- section slider begin -->
    <?php echo $__env->make('front.slider',compact('sliders'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- section close -->
    <!-- section overlay begin -->
    <?php echo $__env->make('front.overlay',compact('branches'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->
    <!-- section identity begin -->
    <?php echo $__env->make('front.who',compact('about'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->
    <!-- section begin -->
    <?php echo $__env->make('front.tracking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->
    <!-- ============================ Smart Testimonials ================================== -->
    <?php echo $__env->make('front.testimonials',compact('testimonial'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============================ Smart Testimonials End ================================== -->
    <!-- section begin -->
    <?php echo $__env->make('front.doing',compact('service'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->
    <!-- section begin -->
    <?php echo $__env->make('front.why-us',compact('pro'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->
    <!-- section begin -->
    <?php echo $__env->make('front.calc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- section close -->







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/front/index.blade.php ENDPATH**/ ?>