
<div class="image-cover page-title" style="background:url( <?php echo e($header['img']); ?> ) no-repeat;" data-overlay="6">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">

                <h2 class="ipt-title"> <?php echo e($header['title']); ?> </h2>
                <span class="ipn-subtitle text-light"> <?php echo e($header['h2']); ?> </span>

            </div>
        </div>
    </div>
</div>
<!-- subheader close -->
<?php /**PATH C:\wamp64\www\shipp\resources\views/front\page-header.blade.php ENDPATH**/ ?>