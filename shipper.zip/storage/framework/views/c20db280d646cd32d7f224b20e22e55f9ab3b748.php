<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.content')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/sliders')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.slider.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/identities')); ?>"><i class="nav-icon icon-plane"></i> <?php echo e(trans('admin.identity.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/pros')); ?>"><i class="nav-icon icon-ghost"></i> <?php echo e(trans('admin.pro.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/services')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.service.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/jobs')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.job.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/applications')); ?>"><i class="nav-icon icon-star"></i> <?php echo e(trans('admin.application.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/testimonials')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.testimonial.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/socials')); ?>"><i class="nav-icon icon-flag"></i> <?php echo e(trans('admin.social.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/pages')); ?>"><i class="nav-icon icon-globe"></i> <?php echo e(trans('admin.page.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/contacts')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.contact.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/clients')); ?>"><i class="nav-icon icon-book-open"></i> <?php echo e(trans('admin.client.title')); ?></a></li>
           

            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.settings')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('seo/translations')); ?>"><i class="nav-icon icon-location-pin"></i> <?php echo e(__('Translations')); ?></a></li>
            
            
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH C:\wamp64\www\shipp\resources\views/seo/layout/sidebar.blade.php ENDPATH**/ ?>