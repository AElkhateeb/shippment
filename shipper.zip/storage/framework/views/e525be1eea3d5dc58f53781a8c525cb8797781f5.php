<?php $__env->startSection('title', trans('admin.identity.actions.edit', ['name' => $identity->title])); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-xl">
        <div class="card">

            <identity-form
                :action="'<?php echo e($identity->seo_url); ?>'"
                :data="<?php echo e($identity->toJsonAllLocales()); ?>"
                :locales="<?php echo e(json_encode($locales)); ?>"
                :send-empty-locales="false"
                v-cloak
                inline-template>

                <form class="form-horizontal form-edit" method="post" @submit.prevent="onSubmit" :action="action" novalidate>


                    <div class="card-header">
                        <i class="fa fa-pencil"></i> <?php echo e(trans('admin.identity.actions.edit', ['name' => $identity->title])); ?>

                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('seo.identity.components.form-elements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('seo.includes.media-uploader', [
                        'mediaCollection' => app(App\Models\Identity::class)->getMediaCollection('identity'),
                        'media' => $identity->getThumbs200ForCollection('identity'),
                        'label' => 'Image'
                      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>


                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary" :disabled="submiting">
                            <i class="fa" :class="submiting ? 'fa-spinner' : 'fa-download'"></i>
                            <?php echo e(trans('brackets/admin-ui::admin.btn.save')); ?>

                        </button>
                    </div>

                </form>

        </identity-form>

        </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('seo.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shipp\resources\views/seo/identity/edit.blade.php ENDPATH**/ ?>