<?php
$right=(App::currentLocale()=='en')? 0: 1; ?>
<section >
    <div class="container">
    <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- row Start -->
        <div class="row align-items-center">
            <?php if($right%2==1): ?>
            <div class="col-lg-6 col-md-6">
                <img src="<?php echo e(URL::asset($about['media_url'])); ?>" class="img-fluid" alt="" />
            </div>
            <?php endif; ?>
            <div class="col-lg-6 col-md-6">
                <div class="story-wrap explore-content">

                    <h2><?php echo e($about['title']); ?></h2>
                    <?php echo $about['text']; ?>

                </div>
            </div>
                <?php if($right%2==0): ?>
                    <div class="col-lg-6 col-md-6">
                        <img src="<?php echo e(URL::asset($about['media_url'])); ?>" class="img-fluid" alt="" />
                    </div>
                <?php endif; ?>
        </div>
        <!-- /row -->
            <?php $right++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>
<?php /**PATH C:\wamp64\www\shipp\resources\views/front\identity.blade.php ENDPATH**/ ?>